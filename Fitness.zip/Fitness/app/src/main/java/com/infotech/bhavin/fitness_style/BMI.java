package com.infotech.bhavin.fitness_style;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BMI extends AppCompatActivity {
    private EditText height,weight;
    private TextView result;
    private Button btn_bmi_calc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);
        getSupportActionBar().setTitle("BMI Calculator");
        height = findViewById(R.id.txt_height);
        weight = findViewById(R.id.txt_weight);
        result = findViewById(R.id.lblresult);
        btn_bmi_calc = findViewById(R.id.btn_bmi_calc);

        btn_bmi_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBMI();
            }
        });
    }

    public void calculateBMI() {
        String heightStr = height.getText().toString();
        String weightStr = weight.getText().toString();

        if (validate())
        {
            float heightValue = Float.parseFloat(heightStr) / 100;
            float weightValue = Float.parseFloat(weightStr);
            float bmi = weightValue / (heightValue * heightValue);
            displayBMI(bmi);
        }
    }

    private boolean validate() {
        boolean flag = true;
        String heightStr = height.getText().toString();
        String weightStr = weight.getText().toString();
        if (heightStr.length()==0 || Integer.parseInt(heightStr)<=0)
        {
            height.setError("Enter Height");
            flag = false;
        }
        if(weightStr.length()==0 || Integer.parseInt(weightStr)<=0)
        {
            weight.setError("Enter Weight");
            flag = false;
        }
        return flag;
    }

    private void displayBMI(float bmi) {
        String bmiLabel = "";

        if (Float.compare(bmi, 15f) <= 0) {
            bmiLabel = "Very severely underweight";
        } else if (Float.compare(bmi, 15f) > 0  &&  Float.compare(bmi, 16f) <= 0) {
            bmiLabel = "Severely underweight";
        } else if (Float.compare(bmi, 16f) > 0  &&  Float.compare(bmi, 18.5f) <= 0) {
            bmiLabel = "Underweight";
        } else if (Float.compare(bmi, 18.5f) > 0  &&  Float.compare(bmi, 25f) <= 0) {
            bmiLabel = "Normal (Healthy weight)";
        } else if (Float.compare(bmi, 25f) > 0  &&  Float.compare(bmi, 30f) <= 0) {
            bmiLabel = "Overweight";
        } else if (Float.compare(bmi, 30f) > 0  &&  Float.compare(bmi, 35f) <= 0) {
            bmiLabel = "Obese class I (Moderately obese)";
        } else if (Float.compare(bmi, 35f) > 0  &&  Float.compare(bmi, 40f) <= 0) {
            bmiLabel = "Obese class II (Severely obese)";
        } else {
            bmiLabel = "Obese class III (Very severely obese)";
        }
        bmiLabel = bmi + "\n\n" + bmiLabel;
        result.setText(bmiLabel);
    }
}
