package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

/**
 * Created by ankitpatel on 10/04/19.
 */

public class CalorieAdapter extends RecyclerView.Adapter
{
    private Context ctx;
    private ArrayList<Calorie> CList = new ArrayList<>();

    DataStorage storage;
    public CalorieAdapter(Context ctx, ArrayList<Calorie> CList) {
        this.ctx = ctx;
        this.CList = CList;
        storage = new DataStorage(ctx,ctx.getResources().getString(R.string.filename));

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                                      int viewType) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View cview = inflater.inflate(R.layout.row_calorie,null);
        MyWidgetContainer container = new MyWidgetContainer(cview);
        return container;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder,
                                 int position)
    {
        MyWidgetContainer container = (MyWidgetContainer) holder;
        final Calorie c = CList.get(position);
        container.lblcfood.setText("Food :- " + c.getTitle());
        container.lblccalorie.setText("Calorie :- " + c.getCalorie());
        container.lblweight.setText("Weight :- " + c.getWeight());
        container.btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddToFood(c);
            }
        });
    }
    public void AddToFood(Calorie c)
    {
        //http://localhost:8888/project1/ws/addtofood.php?reg_userid=1&caloriecounterid=1
        int userid = Integer.parseInt(storage.read("id",DataStorage.INTEGER).toString());
        String WebServiceUrl = Common.GetWebServiceUrl() + "addtofood.php?reg_userid=" + userid
                + "&caloriecounterid=" + c.getId();
        final JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl,
                new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d("india",response.toString());
                String error = null;
                try
                {
                    error = response.getJSONObject(0).getString("error");
                    if(error.equals("no error")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        Toast.makeText(ctx,response.getJSONObject(1).getString("message"),
                                Toast.LENGTH_SHORT).show();
                    }
                }
                catch (JSONException e) {
                    Common.showDialog(ctx,e.getMessage());
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request);
    }
    @Override
    public int getItemCount() {
        return this.CList.size();
    }

    class MyWidgetContainer extends  RecyclerView.ViewHolder
    {
        public TextView lblcfood,lblccalorie,lblweight;
        public ImageView btnadd;
        public MyWidgetContainer(View v)
        {
            super(v);
            lblcfood = v.findViewById(R.id.lblcfood);
            lblccalorie = v.findViewById(R.id.lblccalorie);
            lblweight = v.findViewById(R.id.lblweight);
            btnadd = v.findViewById(R.id.btnadd);
        }
    }
}
