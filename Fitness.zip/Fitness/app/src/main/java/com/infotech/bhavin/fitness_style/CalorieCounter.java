package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class CalorieCounter extends AppCompatActivity {
    private EditText txtfoodname,txtcalorie;
    private Button btnaddcalorie;
    public ArrayList<FoodGetSet> foodArrayList = new ArrayList<>();
    private FoodGetSet fGetSet;
    private Context ctx = this;
    private String food,calorie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calorie_counter);
        getSupportActionBar().setTitle("Calorie Counter");
        allocateMemory();
        btnaddcalorie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                food = txtfoodname.getText().toString().trim();
                calorie = txtcalorie.getText().toString().trim();
                if (food.length()==0)
                    txtfoodname.setError("food name can not be blank");
                else if (calorie.length()==0)
                    txtcalorie.setError("calorie can not be blank");
                else {
                    fGetSet = new FoodGetSet();
                    fGetSet.setFoodname(food);
                    fGetSet.setCalorie(calorie);
                    foodArrayList.add(fGetSet);
                    startActivity(new Intent(ctx,FoodList.class)
                                .putExtra("arrlist",foodArrayList));
                }
            }
        });
    }

    private void allocateMemory() {
        txtcalorie = findViewById(R.id.txtcalorie);
        txtfoodname = findViewById(R.id.txtfoodname);
        btnaddcalorie = findViewById(R.id.btnaddcalorie);
    }
}
