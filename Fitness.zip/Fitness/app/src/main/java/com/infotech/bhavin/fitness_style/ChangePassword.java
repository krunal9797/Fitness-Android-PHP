package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;

public class ChangePassword extends AppCompatActivity {
    private EditText txtoldpassword,txtnewpassword,txtnewpassword1;
    private TextView lblchangepwd;
    private boolean flag=true;
    private Context ctx = this;
    private String oldpassword,newpassword,newpassword1;
    Object userid=null;
    DataStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        allocatememory();

        lblchangepwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validateInfo())
                {
                    makechangepassrequest();
                }
            }
        });
    }

    private void makechangepassrequest() {
        String url= Common.GetWebServiceUrl()+"change_password.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String res)
                    {
                        try
                        {
                            JSONArray response = new JSONArray(res);
                            String error = response.getJSONObject(0).getString("error");
                            if(error.equals("no error")==false)
                                Common.showDialog(ctx,error);
                            else
                            {
                                String success = response.getJSONObject(1).getString("success");
                                String message = response.getJSONObject(2).getString("message");
                                Toast.makeText(ctx,message,Toast.LENGTH_LONG).show();
                                if(success.equals("yes")==true)
                                    finish();
                            }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Common.showDialog(ctx,error.getMessage());
                    }
                }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("id", String.valueOf(userid));
                params.put("oldpwd",oldpassword);
                params.put("newpwd",newpassword);
                return params;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(10000,5,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        AppController.getInstance().addToRequestQueue(stringRequest);
    }

    public void allocatememory()
    {
        storage = new DataStorage(ctx,getResources().getString(R.string.filename));
        userid = Integer.parseInt(storage.read("id", DataStorage.INTEGER).toString());

        txtoldpassword = (EditText) findViewById(R.id.txtoldpassword);
        txtnewpassword = (EditText) findViewById(R.id.txtnewpassword);
        txtnewpassword1 = (EditText) findViewById(R.id.txtnewpassword1);
        lblchangepwd = (TextView) findViewById(R.id.btnchangepwd);
    }

    private boolean validateInfo()
    {
        flag = true;
        String msg = "";
        oldpassword = txtoldpassword.getText().toString();
        newpassword = txtnewpassword.getText().toString();
        newpassword1 = txtnewpassword1.getText().toString();

        if(oldpassword.length()==0)
        {
            txtoldpassword.requestFocus();
            txtoldpassword.setError("Enter minimum 4 digit Password");
            flag = false;
        }

        if(newpassword.length()==0)
        {
            txtnewpassword.requestFocus();
            txtnewpassword.setError("Password must be require");
            flag = false;
        }

        if(newpassword1.length()==0)
        {

            txtnewpassword1.requestFocus();
            txtnewpassword1.setError("Password must be require");
            flag = false;
        }

        if(newpassword.equals(newpassword1)==false) {
            txtnewpassword1.requestFocus();
            txtnewpassword1.setError("Both Password must be same");
            flag = false;
        }
        return flag;
    }
}
