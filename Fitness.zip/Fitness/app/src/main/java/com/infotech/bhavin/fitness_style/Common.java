package com.infotech.bhavin.fitness_style;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class Common
{
    private static final String HOST = "http://192.168.1.106:8888/";
    public static String GetBaseUrl()
    {
        return HOST + "project1/";
    }
    public static String GetWebServiceUrl()
    {
        return GetBaseUrl() + "ws/";
    }
    public static String GetImageUrl()
    {
        return GetBaseUrl() + "admin/image/receipe/";
    }

    public static void showDialog(Context ctx)
    {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Timeout Message");
        b1.setMessage("possible solutions \n"
                + "\n 1) make sure that you laptop and phone is in same network" +
                "\n 2) make sure that wamp/ampp/mamp is running in background" +
                "\n 3) make sure that ip address of your laptop is set in IP constant"
        + "\n 4) make sure webservice path and name is correct");
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }

    public static void showDialog(Context ctx,String msg)
    {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Error");
        b1.setMessage(msg);
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }
}
