package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class Dashboard extends AppCompatActivity
{
    private Context ctx = this;
    private LinearLayout lay_bmi,lay_dietplan,lay_healthytips
            ,lay_caloriecounter,lay_healthyreceipe,lay_logout;
    private DataStorage storage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        allocateMemory();
        setListener();
    }

    private void allocateMemory() {
        storage = new DataStorage(ctx,getResources().getString(R.string.filename));
        lay_bmi = findViewById(R.id.lay_bmi);
        lay_dietplan = findViewById(R.id.lay_dietplan);
        lay_healthytips = findViewById(R.id.lay_healthytips);
        lay_caloriecounter = findViewById(R.id.lay_caloriecounter);
        lay_healthyreceipe = findViewById(R.id.lay_healthyreceipe);
        lay_logout = findViewById(R.id.lay_logout);
    }

    private void setListener() {
        lay_bmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,BMI.class));
            }
        });

        lay_caloriecounter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,FoodList.class)
                        .putExtra("arrlist",new ArrayList<FoodGetSet>()));
            }
        });

        lay_dietplan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,Plan.class));
            }
        });

        lay_healthyreceipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,ReceipeActivity.class));
            }
        });

        lay_healthytips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,Tips.class));
            }
        });

        lay_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                storage.write("id",-1);
                startActivity(new Intent(ctx,Login.class));
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.changepwd)
        {
            startActivity(new Intent(ctx,ChangePassword.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
