package com.infotech.bhavin.fitness_style;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class DataStorage implements ActivityCompat.OnRequestPermissionsResultCallback
{
    private SharedPreferences pref;
    private SharedPreferences.Editor writer;
    private String FileName;
    private Context ctx;
    Activity MyActivity;
    public final static  int INTEGER = 1;
    public final static  int FLOAT = 2;
    public final static  int STRING = 3;
    public final static  int LONG = 4;
    public final static  int BOOLEAN = 5;

    public DataStorage(Context ctx, String FileName)
    {
        this.ctx = ctx;
        this.FileName = FileName;
        pref = ctx.getSharedPreferences(this.FileName,Context.MODE_PRIVATE);
        writer = pref.edit();
    }
    public void write(String key,int value)
    {
        writer.putInt(key,value);
        writer.commit();
    }
    public void write(String key,float value)
    {
        writer.putFloat(key,value);
        writer.commit();
    }
    public void write(String key,String value)
    {
        writer.putString(key,value);
        writer.commit();
    }
    public void write(String key,long value)
    {
        writer.putLong(key,value);
        writer.commit();
    }
    public void write(String key,Boolean value)
    {
        writer.putBoolean(key,value);
        writer.commit();
    }
    public Object read(String key,int DataType)
    {
        Object temp = new Object();
        if(DataType==INTEGER)
        {
            temp = pref.getInt(key,0);
        }
        else if(DataType==FLOAT)
        {
            temp = pref.getFloat(key,0.0f);
        }
        else if(DataType==LONG)
        {
            temp = pref.getLong(key,0L);
        }
        else if(DataType==STRING)
        {
            temp = pref.getString(key,"");
        }
        else if(DataType==BOOLEAN)
        {
            temp = pref.getBoolean(key,false);
        }
        return temp;
    }
    public String ReadFileFromApp(int FileId)
    {
        Resources res = ctx.getResources();
        InputStream is = res.openRawResource(FileId);
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader reader = new BufferedReader(isr);
        StringBuffer buffer = new StringBuffer();
        String line;
        try
        {
            while((line = reader.readLine())!=null)
            {
                buffer.append(line + "\n");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return buffer.toString();
    }
    //FileName = fruit/apple/ankit.txt
    public int CreateFileInExternalStorage(String FileName,String FileContent)
    {
        int isError=1;
        File MyFile = new File(Environment.getExternalStorageDirectory() + "/" + FileName);
        MyFile.getParentFile().mkdirs();
        try
        {
            MyFile.createNewFile();
            FileOutputStream FileWriter = new FileOutputStream(MyFile);
            byte[] FileData = FileContent.getBytes();
            FileWriter.write(FileData);
            FileWriter.close();
            isError=0;
        }
        catch (IOException e)
        {
            Toast.makeText(ctx,e.getMessage(),Toast.LENGTH_LONG).show();
        }
        return isError;
    }
    public String ReadFileFromExternalStorage(String FileName)
    {
        File MyFile = new File(Environment.getExternalStorageDirectory() + "/" + FileName);
        if(MyFile.exists()==false)
            return "File Not Found";
        else
        {
            try
            {
                StringBuffer Content = new StringBuffer((int) (MyFile.length()+1));
                FileInputStream FileReader = new FileInputStream(MyFile);
                byte packet[] = new byte[1024];
                int ReadCount=0;
                while((ReadCount=FileReader.read(packet))!=-1)
                {
                    Content.append(new String(packet));
                }
                return Content.toString();
            }
            catch (FileNotFoundException e)
            {
                return "File Not Found";
            }
            catch (IOException e) {
                return "Error in read operation";
            }
        }
    }

    public void CheckPermission()
    {
        int permission = Integer.parseInt(read("permission",INTEGER).toString());
        if(permission==0) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                if (ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                        ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    MyActivity = (Activity) ctx;
                    String[] PermissionList = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    MyActivity.requestPermissions(PermissionList, 145);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        if(requestCode==145)
        {
            for(int i=0;i<grantResults.length;i++)
            {
                if(grantResults[i]!=PackageManager.PERMISSION_GRANTED)
                    System.exit(1);
            }
            write("permission",1);
        }
    }
}