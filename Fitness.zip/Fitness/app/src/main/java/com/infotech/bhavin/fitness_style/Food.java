package com.infotech.bhavin.fitness_style;

/**
 * Created by ankitpatel on 11/04/19.
 */

public class Food
{
    private int id;
    private String title,weight,calorie;

    public Food(int id, String title, String weight, String calorie) {
        this.id = id;
        this.title = title;
        this.weight = weight;
        this.calorie = calorie;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getWeight()
    {
        return weight;
    }

    public void setWeight(String weight)
    {
        this.weight = weight;
    }

    public String getCalorie()
    {
        return calorie;
    }

    public void setCalorie(String calorie)
    {
        this.calorie = calorie;
    }
}
