package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.myHolder>
{
    private Context ctx;
    private ArrayList<FoodGetSet> arr_adapter;

    public FoodAdapter(Context ctx, ArrayList<FoodGetSet> arr_adapter)
    {
        this.ctx = ctx;
        this.arr_adapter = arr_adapter;
    }

    @NonNull
    @Override
    public myHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View iView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_calorie,parent,false);
        return new myHolder(iView);
    }

    @Override
    public void onBindViewHolder(@NonNull myHolder holder, final int position) {
        holder.lblcfood.setText(arr_adapter.get(position).getFoodname().trim());
        holder.lblccalorie.setText(arr_adapter.get(position).getCalorie().trim());
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    public class myHolder extends RecyclerView.ViewHolder
    {
        public TextView lblcfood,lblccalorie;

        public myHolder(View itemView) {
            super(itemView);
            lblcfood = itemView.findViewById(R.id.lblcfood);
            lblccalorie = itemView.findViewById(R.id.lblccalorie);
        }
    }
}
