package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FoodContainer extends AppCompatActivity {

    ArrayList<Food> FoodList = new ArrayList<>();
    private Context ctx = this;
    private RecyclerView recfood;
    private DataStorage storage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_container);
        allocatememory();
        SendRequest();
    }

    private void SendRequest()
    {
        int reg_userid = Integer.parseInt(storage.read("id",DataStorage.INTEGER).toString());
        String WebServiceUrl = Common.GetWebServiceUrl() + "food.php?reg_userid=" + reg_userid;
        final JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d("india",response.toString());
                String error = null;
                try
                {
                    error = response.getJSONObject(0).getString("error");
                    if(error.equals("no error")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        int count = response.getJSONObject(1).getInt("total");
                        if(count==0)
                        {
                            Common.showDialog(ctx,"No record found");
                        }
                        else
                        {
                            int size = response.length();
                            for(int i=3;i<size;i++)
                            {
                                JSONObject o = response.getJSONObject(i);
                                int id = Integer.parseInt(o.getString("id"));
                                String title = o.getString("title");
                                String calorie = o.getString("calorie");
                                String weight = o.getString("weight");
                                Food c = new Food(id,title,calorie,weight);
                                FoodList.add(c);
                            }
                            MyFoodAdapter fa = new MyFoodAdapter(ctx,FoodList);
                            recfood.setLayoutManager(new GridLayoutManager(ctx,1));
                            recfood.setItemAnimator(new DefaultItemAnimator());
                            recfood.setAdapter(fa);
                        }

                    }
                }
                catch (JSONException e) {
                    Common.showDialog(ctx,e.getMessage());
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request);
    }

    private void allocatememory() {
        recfood = findViewById(R.id.recfood);
        storage = new DataStorage(ctx,ctx.getResources().getString(R.string.filename));
    }
}
