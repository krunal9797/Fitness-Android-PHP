package com.infotech.bhavin.fitness_style;

/**
 * Created by ankitpatel on 10/04/19.
 */

public class FoodGetSet
{
    String foodname,calorie;

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public String getCalorie() {
        return calorie;
    }

    public void setCalorie(String calorie) {
        this.calorie = calorie;
    }
}
