package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FoodList extends AppCompatActivity {
    ArrayList<Calorie> Clist = new ArrayList<>();
    private Context ctx = this;
    private RecyclerView rcvfood;
    private ImageView fab_addfood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);
        allocatememory();
        SendRequest();
        SetEvents();
    }
    private void SetEvents()
    {
        fab_addfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,FoodContainer.class));
            }
        });
    }
    private void SendRequest()
    {
        String WebServiceUrl = Common.GetWebServiceUrl() + "CalorieCounter.php";
        final JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d("india",response.toString());
                String error = null;
                try
                {
                    error = response.getJSONObject(0).getString("error");
                    if(error.equals("no error")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        int count = response.getJSONObject(1).getInt("total");
                        if(count==0)
                        {
                            Common.showDialog(ctx,"No record found");
                        }
                        else
                        {
                            int size = response.length();
                            for(int i=2;i<size;i++)
                            {
                                JSONObject o = response.getJSONObject(i);
                                int id = Integer.parseInt(o.getString("id"));
                                String title = o.getString("title");
                                String calorie = o.getString("calorie");
                                String weight = o.getString("weight");
                                Calorie c = new Calorie(id,title,calorie,weight);
                                Clist.add(c);
                            }
                            CalorieAdapter ca = new CalorieAdapter(ctx,Clist);
                            rcvfood.setLayoutManager(new GridLayoutManager(ctx,1));
                            rcvfood.setItemAnimator(new DefaultItemAnimator());
                            rcvfood.setAdapter(ca);
                        }

                    }
                }
                catch (JSONException e) {
                    Common.showDialog(ctx,e.getMessage());
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request);
    }

    private void allocatememory() {
        rcvfood = findViewById(R.id.rcvfood);
        fab_addfood = findViewById(R.id.fab_addfood);
        fab_addfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,CalorieCounter.class));
            }
        });
    }
}
