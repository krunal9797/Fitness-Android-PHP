package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;

public class ForgotPassword extends AppCompatActivity {
    private Context ctx = this;
    private EditText txtfgtemail;
    private TextView btnsendpwd;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        getSupportActionBar().setTitle("Forgot Password");

        allocateMemory();

        btnsendpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidateInput()==true)
                {
                    sendEmail();
                }
            }
        });
    }

    private void allocateMemory() {
        txtfgtemail = findViewById(R.id.txtfgtemail);
        btnsendpwd = findViewById(R.id.btnsendpwd);
    }

    public boolean ValidateInput()
    {
        boolean isvalid = true;
        email = txtfgtemail.getText().toString().trim().toLowerCase();
        if(email.length()==0)
        {
            isvalid=false;
            txtfgtemail.setError("email can not be blank");
        }
        return isvalid;
    }

    private void sendEmail() {
        String WebServiceUrl = Common.GetWebServiceUrl() + "forgotpassword.php";
        StringRequest request = new StringRequest(StringRequest.Method.POST, WebServiceUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String res)
            {
                try
                {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if(error.equals("no error")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        //no error
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx,message,Toast.LENGTH_LONG).show();
                        if(success.equals("yes")==true)
                        {
                            finish();
                        }
                    }
                } catch (JSONException e) {
                    Common.showDialog(ctx,e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Common.showDialog(ctx,error.toString());
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> data = new HashMap<>();
                data.put("email",email);
                return data;
            }
        };
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request); //call webservice
    }
}
