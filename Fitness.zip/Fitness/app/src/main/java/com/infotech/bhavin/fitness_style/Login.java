package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;

public class Login extends AppCompatActivity {
    private Context ctx = this;
    private Button btnlogin;
    private TextView btnsignup,btnforgetpwd;
    private EditText txtemail,txtpassword;
    private String email,password;
    private DataStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("Login");

        allocatememory();
        setListener();
    }

    private void setListener()
    {
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidateInput()==true)
                {
                    loginUser();
                }
            }
        });

        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(ctx,Register.class));
                finish();
            }
        });

        btnforgetpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx,ForgotPassword.class));
                finish();
            }
        });
    }

    private void allocatememory() {
        storage = new DataStorage(ctx,getResources().getString(R.string.filename));
        txtemail = findViewById(R.id.txtemail);
        txtpassword = findViewById(R.id.txtpassword);
        btnlogin = findViewById(R.id.btnlogin);
        btnsignup = findViewById(R.id.btnsignup);
        btnforgetpwd = findViewById(R.id.btnforgetpwd);
    }

    private boolean ValidateInput()
    {
        boolean isvalid = true;
        email = txtemail.getText().toString().trim().toLowerCase();
        password = txtpassword.getText().toString().trim();

        if(email.length()==0)
        {
            isvalid=false;
            txtemail.setError("email can not be blank");
        }
        if(password.length()==0)
        {
            isvalid=false;
            txtpassword.setError("password can not be blank");
        }
        return isvalid;
    }

    private void loginUser() {
        String WebServiceUrl = Common.GetWebServiceUrl()  +
                "login.php?email=" + email + "&password=" + password;
        JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response)
                    {
                        try
                        {
                            String error = response.getJSONObject(0).getString("error");
                            if(error.equals("no error")==false)
                                Common.showDialog(ctx,error);
                            else
                            {
                                //no error
                                String success = response.getJSONObject(1).getString("success");
                                String message = response.getJSONObject(2).getString("message");
                                Toast.makeText(ctx,message,Toast.LENGTH_LONG).show();
                                if(success.equals("yes")==true)
                                {
                                    String id = response.getJSONObject(3).getString("id");
                                    storage.write("id",Integer.parseInt(id));
                                    startActivity(new Intent(ctx,Dashboard.class));
                                    finish();
                                }
                            }
                        }
                        catch (JSONException e)
                        {
                            Common.showDialog(ctx,e.getMessage());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Common.showDialog(ctx,error.toString());
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request);
    }
}
