package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
public class MyFoodAdapter extends RecyclerView.Adapter
{
    private Context ctx;
    private ArrayList<Food> FoodList;
    public MyFoodAdapter(Context ctx, ArrayList<Food> foodList)
    {
        this.ctx = ctx;
        FoodList = foodList;
   }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View cview = inflater.inflate(R.layout.food_row,null);
        MyWidgetContainer container = new MyWidgetContainer(cview);
        return container;    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position)
    {
        MyWidgetContainer container = (MyWidgetContainer) holder;
        final Food c = FoodList.get(position);
        container.lblcfood.setText("Food :- " + c.getTitle());
        container.lblccalorie.setText("Calorie :- " + c.getCalorie());
        container.lblweight.setText("Weight :- " + c.getWeight());
        container.btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteFromFood(c.getId(),position);
            }
        });
    }
    private void DeleteFromFood(int foodid, final int position)
    {
        String WebServiceUrl = Common.GetWebServiceUrl() +
                "deletefromfood.php?id=" + foodid;
        final JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("india",response.toString());
                        String error = null;
                        try
                        {
                            error = response.getJSONObject(0).getString("error");
                            if(error.equals("no error")==false)
                            {
                                Common.showDialog(ctx,error);
                            }
                            else
                            {
                                Toast.makeText(ctx,response.getJSONObject(1).getString("message"),
                                        Toast.LENGTH_SHORT).show();
                                FoodList.remove(position);
                                notifyDataSetChanged();
                            }
                        }
                        catch (JSONException e) {
                            Common.showDialog(ctx,e.getMessage());
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,
                3,1));
        AppController.getInstance().addToRequestQueue(request);
    }
    @Override
    public int getItemCount()
    {
        return FoodList.size();
    }

    class MyWidgetContainer extends  RecyclerView.ViewHolder
    {
        public TextView lblcfood,lblccalorie,lblweight;
        public ImageView btndelete;
        public MyWidgetContainer(View v)
        {
            super(v);
            lblcfood = v.findViewById(R.id.lblcfood2);
            lblccalorie = v.findViewById(R.id.lblccalorie2);
            lblweight = v.findViewById(R.id.lblweight2);
            btndelete = v.findViewById(R.id.btndelete);
        }
    }
}
