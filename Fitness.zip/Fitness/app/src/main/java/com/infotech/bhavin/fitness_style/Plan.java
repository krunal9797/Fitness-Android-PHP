package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Plan extends AppCompatActivity {
    private Context ctx = this;
    private RecyclerView rcvdietplan;
    private ArrayList<PlanGetSet> arr_adapter = new ArrayList<>();
    private PlanAdapter pAdapter;
    private PlanGetSet pGetSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_plan);
        getSupportActionBar().setTitle("Diet Plan");
        rcvdietplan = findViewById(R.id.rcvdietplan);
        getReceipeList();
    }

    public void getReceipeList()
    {
        String WebServiceUrl = Common.GetWebServiceUrl() + "view-dietplan.php";
        StringRequest request = new StringRequest(StringRequest.Method.POST,
                WebServiceUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String res) {
                try
                {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if(error.equals("no")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        //no error
                        int total = response.getJSONObject(1).getInt("total");
                        if(total==0)
                        {
                            rcvdietplan.setVisibility(View.GONE);
                        }
                        else
                        {
                            int size = response.length();
                            for(int i=2;i<size;i++)
                            {
                                JSONObject object = response.getJSONObject(i);
                                pGetSet = new PlanGetSet();
                                pGetSet.setMeal(object.getString("meal"));
                                pGetSet.setFood(object.getString("food"));
                                pGetSet.setDiettype(object.getString("diet_type"));
                                arr_adapter.add(pGetSet);
                            }
                            pAdapter = new PlanAdapter(ctx,arr_adapter);
                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                            rcvdietplan.setLayoutManager(mLayoutManager);
                            rcvdietplan.setAdapter(pAdapter);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Common.showDialog(ctx,error.toString());
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request);
    }
}
