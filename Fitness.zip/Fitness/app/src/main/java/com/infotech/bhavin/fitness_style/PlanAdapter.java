package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class PlanAdapter extends RecyclerView.Adapter<PlanAdapter.myHolder>
{
    private Context ctx;
    private ArrayList<PlanGetSet> arr_adapter;
    private String[] diettype = {
            "Standard Diet",
            "Vegetarian Diet"
    };
    private String[] meal = {
            "Meal",
            "Breakfast",
            "Snack",
            "Lunch",
            "Dinner"
    };

    public PlanAdapter(Context ctx, ArrayList<PlanGetSet> arr_adapter)
    {
        this.ctx = ctx;
        this.arr_adapter = arr_adapter;
    }

    @NonNull
    @Override
    public myHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View iView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_plan,parent,false);
        return new myHolder(iView);
    }

    @Override
    public void onBindViewHolder(@NonNull myHolder holder, final int position) {
        holder.plan_food.setText(arr_adapter.get(position).getFood().trim());
        holder.plan_diettype.setText(diettype[Integer.parseInt(arr_adapter.get(position).getDiettype())]);
        holder.lblplan_meal.setText(meal[Integer.parseInt(arr_adapter.get(position).getMeal())]);
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    public class myHolder extends RecyclerView.ViewHolder
    {
        public TextView lblplan_meal,plan_food,plan_diettype;

        public myHolder(View itemView) {
            super(itemView);
            lblplan_meal = itemView.findViewById(R.id.lblplan_meal);
            plan_food = itemView.findViewById(R.id.plan_food);
            plan_diettype = itemView.findViewById(R.id.plan_diettype);
        }
    }
}
