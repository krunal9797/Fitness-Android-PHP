package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ReceipeActivity extends AppCompatActivity {
    private Context ctx = this;
    private RecyclerView rcvreceipe;
    private ArrayList<ReceipeGetSet> arr_adapter = new ArrayList<>();
    private ReceipeAdapter rAdapter;
    private ReceipeGetSet rGetSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipe);
        getSupportActionBar().setTitle("Healthy Receipe");
        rcvreceipe = findViewById(R.id.rcvreceipe);
        getReceipeList();
    }

    public void getReceipeList()
    {
        String WebServiceUrl = Common.GetWebServiceUrl() + "view-receipe.php";
        StringRequest request = new StringRequest(StringRequest.Method.POST,
                WebServiceUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String res) {
                try
                {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if(error.equals("no")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        //no error
                        int total = response.getJSONObject(1).getInt("total");
                        if(total==0)
                        {
                            rcvreceipe.setVisibility(View.GONE);
                        }
                        else
                        {
                            int size = response.length();
                            for(int i=2;i<size;i++)
                            {
                                JSONObject object = response.getJSONObject(i);
                                rGetSet = new ReceipeGetSet();
                                rGetSet.setTitle(object.getString("title"));
                                rGetSet.setDetail(object.getString("howtomake"));
                                rGetSet.setIngredients(object.getString("ingredients"));
                                rGetSet.setPhoto(object.getString("image"));
                                arr_adapter.add(rGetSet);
                            }
                            rAdapter = new ReceipeAdapter(ctx,arr_adapter);
                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                            rcvreceipe.setLayoutManager(mLayoutManager);
                            rcvreceipe.setAdapter(rAdapter);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Common.showDialog(ctx,error.toString());
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request);
    }
}
