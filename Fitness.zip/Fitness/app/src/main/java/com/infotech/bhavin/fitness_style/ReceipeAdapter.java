package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import java.util.ArrayList;

public class ReceipeAdapter extends RecyclerView.Adapter<ReceipeAdapter.myHolder>
{
    private Context ctx;
    private ArrayList<ReceipeGetSet> arr_adapter;
    private ImageLoader loader;

    public ReceipeAdapter(Context ctx,ArrayList<ReceipeGetSet> arr_adapter)
    {
        this.ctx = ctx;
        this.arr_adapter = arr_adapter;
        loader = AppController.getInstance().getImageLoader();
    }

    @NonNull
    @Override
    public myHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View iView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_receipe,parent,false);
        return new myHolder(iView);
    }

    @Override
    public void onBindViewHolder(@NonNull myHolder holder, final int position) {
        holder.lblreceipe_title.setText(arr_adapter.get(position).getTitle());
        String imgUrl = Common.GetImageUrl() + arr_adapter.get(position).getPhoto();
        holder.imgreceipe_photo.setImageUrl(imgUrl,loader);
        holder.lay_receipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ctx.startActivity(new Intent(ctx,ReceipeDetail.class)
                .putExtra("title",arr_adapter.get(position).getTitle())
                .putExtra("detail",arr_adapter.get(position).getDetail())
                .putExtra("ingredients",arr_adapter.get(position).getIngredients())
                .putExtra("photo",arr_adapter.get(position).getPhoto())
                );
            }
        });
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    public class myHolder extends RecyclerView.ViewHolder
    {
        public TextView lblreceipe_title;
        public LinearLayout lay_receipe;
        public NetworkImageView imgreceipe_photo;

        public myHolder(View itemView) {
            super(itemView);
            lay_receipe = itemView.findViewById(R.id.lay_receipe);
            lblreceipe_title = itemView.findViewById(R.id.lblreceipe_title);
            imgreceipe_photo = (NetworkImageView) itemView.findViewById(R.id.imgreceipe_photo);
        }
    }
}
