package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

public class ReceipeDetail extends AppCompatActivity {

    private Context ctx = this;
    private TextView lbl_ringredients,lbl_rdetail;
    private String title,photo,detail,ingredients;
    private ImageLoader loader;
    private NetworkImageView img_rphoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipe_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        allocateMemory();
    }

    private void allocateMemory() {
        lbl_ringredients = findViewById(R.id.lbl_ringredients);
        lbl_rdetail = findViewById(R.id.lbl_rdetail);
        img_rphoto = (NetworkImageView) findViewById(R.id.img_rphoto);
        loader = AppController.getInstance().getImageLoader();

        title = getIntent().getExtras().getString("title");
        photo = getIntent().getExtras().getString("photo");
        detail = getIntent().getExtras().getString("detail");
        ingredients = getIntent().getExtras().getString("ingredients");

        String imgurl = Common.GetImageUrl() + photo;
        img_rphoto.setImageUrl(imgurl,loader);
        getSupportActionBar().setTitle(title);
        lbl_rdetail.setText(detail);
        lbl_ringredients.setText(ingredients);
    }
}
