package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity
{
    private EditText txtfullname,txtemailid,txtregpassword;
    private Button btnregister;
    private Context ctx = this;
    private String fullname,email,password;
    DataStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setTitle("Register with us");

        allocatememory();
        setevent();
    }

    private void setevent()
    {
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidateInput()==true)
                {
                    registerUser();
                }
            }
        });
    }

    private void registerUser() {
        String WebServiceUrl = Common.GetWebServiceUrl() + "register.php";
        StringRequest request = new StringRequest(StringRequest.Method.POST, WebServiceUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String res)
            {
                try
                {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if(error.equals("no error")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx,message,Toast.LENGTH_LONG).show();
                        if(success.equals("yes")==true)
                        {
                            storage.write("id",-1);
                            startActivity(new Intent(ctx,Login.class));
                            finish();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Common.showDialog(ctx,error.toString());
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> data = new HashMap<>();
                data.put("email",email);
                data.put("password",password);
                data.put("fullname",fullname);
                return data;
            }
        };
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request); //call webservice
    }

    private void allocatememory()
    {
        storage = new DataStorage(ctx,getResources().getString(R.string.filename));
        txtfullname=findViewById(R.id.txtfullname);
        txtemailid=findViewById(R.id.txtregemail);
        txtregpassword=findViewById(R.id.txtregpassword);
        btnregister=findViewById(R.id.btnregister);
    }

    public boolean ValidateInput()
    {
        boolean isvalid = true;
        fullname = txtfullname.getText().toString().trim();
        email = txtemailid.getText().toString().trim().toLowerCase();
        password = txtregpassword.getText().toString().trim();
        if(fullname.length()==0)
        {
            isvalid=false;
            txtfullname.setError("firstname can not be blank");
        }
        if(email.length()==0)
        {
            isvalid=false;
            txtemailid.setError("email can not be blank");
        }
        if (password.length() == 0) {
            isvalid = false;
            txtregpassword.setError("password can not be blank");
        }
        return isvalid;
    }
}
