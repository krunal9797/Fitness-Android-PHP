package com.infotech.bhavin.fitness_style;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;

import java.util.Timer;
import java.util.TimerTask;

public class Splash extends AppCompatActivity {

    private Context ctx = this;
    private ProgressDialog pDialog;
    DataStorage storage;
    private Integer id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        storage = new DataStorage(ctx, getResources().getString(R.string.filename));
        id = Integer.parseInt(storage.read("id", DataStorage.INTEGER).toString());
        openApp();
    }

    private void openApp()
    {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run()
            {
                if (id>0)
                {
                    startActivity(new Intent(ctx,Dashboard.class));
                    finish();
                }
                else
                {
                    startActivity(new Intent(ctx,Login.class));
                    finish();
                }
            }
        }, 1500);
    }
}
