package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Tips extends AppCompatActivity {
    private Context ctx = this;
    private RecyclerView rcvhealthytips;
    private ArrayList<TipsGetSet> arr_adapter = new ArrayList<>();
    private TipsAdapter tAdapter;
    private TipsGetSet tGetSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_healthy_tips);
        getSupportActionBar().setTitle("Healthy Tips");
        rcvhealthytips = findViewById(R.id.rcvhealthytips);
        getReceipeList();
    }

    public void getReceipeList()
    {
        String WebServiceUrl = Common.GetWebServiceUrl() + "view-tips.php";
        StringRequest request = new StringRequest(StringRequest.Method.POST,
                WebServiceUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String res) {
                try
                {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if(error.equals("no")==false)
                    {
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        //no error
                        int total = response.getJSONObject(1).getInt("total");
                        if(total==0)
                        {
                            rcvhealthytips.setVisibility(View.GONE);
                        }
                        else
                        {
                            int size = response.length();
                            for(int i=2;i<size;i++)
                            {
                                JSONObject object = response.getJSONObject(i);
                                tGetSet = new TipsGetSet();
                                tGetSet.setTitle(object.getString("title"));
                                tGetSet.setDetail(object.getString("detail"));
                                arr_adapter.add(tGetSet);
                            }
                            tAdapter = new TipsAdapter(ctx,arr_adapter);
                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                            rcvhealthytips.setLayoutManager(mLayoutManager);
                            rcvhealthytips.setAdapter(tAdapter);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Common.showDialog(ctx,error.toString());
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000,3,1));
        AppController.getInstance().addToRequestQueue(request);
    }
}
