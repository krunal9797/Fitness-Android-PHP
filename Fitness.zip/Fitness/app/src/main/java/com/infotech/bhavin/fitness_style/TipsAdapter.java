package com.infotech.bhavin.fitness_style;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class TipsAdapter extends RecyclerView.Adapter<TipsAdapter.myHolder>
{
    private Context ctx;
    private ArrayList<TipsGetSet> arr_adapter;

    public TipsAdapter(Context ctx, ArrayList<TipsGetSet> arr_adapter)
    {
        this.ctx = ctx;
        this.arr_adapter = arr_adapter;
    }

    @NonNull
    @Override
    public myHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View iView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_tips,parent,false);
        return new myHolder(iView);
    }

    @Override
    public void onBindViewHolder(@NonNull myHolder holder, final int position) {
        holder.lbltips_title.setText(arr_adapter.get(position).getTitle());
        holder.lbltips_detail.setText(arr_adapter.get(position).getDetail());
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    public class myHolder extends RecyclerView.ViewHolder
    {
        public TextView lbltips_title,lbltips_detail;

        public myHolder(View itemView) {
            super(itemView);
            lbltips_title = itemView.findViewById(R.id.lbltips_title);
            lbltips_detail = itemView.findViewById(R.id.lbltips_detail);
        }
    }
}
