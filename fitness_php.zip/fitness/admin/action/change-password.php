<?php

session_start();
require_once ("../../inc/connection.php");
if (isset($_POST['txtpassword'])) {
    if ($_POST['txtnewpassword'] != $_POST['txtnewpassword2']) {
        header("location:../change-password.php?msg=<font color='red'>Password does not match</font>");
    } else {
        $id = $_SESSION['id'];
        extract($_POST);
        $sql = "select id,password from " . ADMIN . " where id = $id";
        $result = mysqli_query($link, $sql)or die(mysqli_error($link));
        $count = mysqli_num_rows($result);
        if ($count == 0) {
            session_destroy();
            setcookie("username", "", time() - 36000);
            header("location:../index.php?msg=<font color='red'>user not found login again</font>");
        } else {
            $row = mysqli_fetch_assoc($result);
            $id = $_SESSION['id'];
            if (MatchPassword($row['password'], $txtpassword) == true) { //successful login
                $password = EncryptPassword($txtnewpassword);
                $sql = "UPDATE " . ADMIN . " SET password='$password' WHERE id=$id";
                $result = mysqli_query($link, $sql)or die(mysqli_error($link));
                session_destroy();
                setcookie("username", "", time() - 36000);
                header("Location:../index.php?msg=your password changed login again");
            } else {
                header("Location:../change-password.php?msg=invalid password");
            }
        }
    }
}
?>