<?php

require_once("../../inc/connection.php");
extract($_POST);
$food = mysqli_real_escape_string($link, $txtfood);
$sql = "insert into dietplan(meal,food,diet_type)values('$rdomeal','$food','$rdo')";
mysqli_query($link, $sql)or die(mysqli_error($link));
$msg = "inserted successfully";
header("location:../insert-dietplan.php?msg=$msg");
?>