<?php

require_once("../../inc/connection.php");
extract($_POST);
$photo = rand(10, 99) . rand(10, 99) . rand(10, 99) . "-" . $_FILES['filphoto']['name'];
move_uploaded_file($_FILES['filphoto']['tmp_name'], "../image/receipe/$photo");
$title = mysqli_real_escape_string($link, $txttitle);
$Ingredients = mysqli_real_escape_string($link, $txtIngredients);
$howmake = mysqli_real_escape_string($link, $txthowmake);
$sql = "insert into receipe(title,Ingredients,howtomake,image)values('$title','$Ingredients','$howmake','$photo')";
mysqli_query($link, $sql) or die(mysqli_error($link));
$msg = "successfully inserted";
header("location:../insert-receipe.php?msg=$msg");
?>