<?php

require_once("../../inc/connection.php");
extract($_POST);
$title = mysqli_real_escape_string($link, $txttitle);
$detail = mysqli_real_escape_string($link, $txtdetail);
$sql = "insert into tips(title,detail)values('$title','$detail')";
mysqli_query($link, $sql) or die(mysqli_error($link));
$msg = "inserted successfully";
header("location:../insert-tips.php?msg=$msg");
?>