<?php

$Opassword = "123123";
echo password_hash($Opassword, PASSWORD_DEFAULT);
//echo $password;
?>