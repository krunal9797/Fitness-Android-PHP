<?php

require_once("../../inc/connection.php");
extract($_POST);
$food = mysqli_real_escape_string($link, $txtfood);
$sql = "update dietplan set meal='$rdomeal',food='$food',diet_type='$rdo' where id='$id'";
mysqli_query($link, $sql) or die(mysqli_error($link));
$msg = "update successfully";
header("location:../dietplan.php?msg=$msg");
