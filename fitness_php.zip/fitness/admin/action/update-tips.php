<?php

require_once("../../inc/connection.php");
extract($_POST);
$title = mysqli_real_escape_string($link, $txttitle);
$detail = mysqli_real_escape_string($link, $txtdetail);
$sql = "update tips set title='$title',detail='$detail' where id='$id'";
mysqli_query($link, $sql)or die(mysqli_error($link));
$msg = "update successfully";
header("location:../tips.php?msg=$msg");
?>