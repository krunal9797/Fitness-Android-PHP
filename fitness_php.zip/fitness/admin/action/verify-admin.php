
<?php

session_start();
require_once( "../../inc/connection.php" );
extract($_POST);
$sql = "select id,password from admin where email='$txtemail'";
$result = mysqli_query($link, $sql)or die(mysqli_error($link));
$count = mysqli_num_rows($result);
if ($count == 0) { //no record found
    header("Location:../index.php?msg=invalid login");
} else {
    $row = mysqli_fetch_assoc($result);
    if (MatchPassword($row['password'], $txtpassword) == true) { //successful login
        //create session variable to track login 
        $_SESSION['id'] = $row['id'];
        header("location:../dashboard.php");
    } else {
        header("Location:../index.php?msg=invalid login");
    }
}
?>