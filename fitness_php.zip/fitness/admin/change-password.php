<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php require_once("inc/header-part.php"); ?>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Change Password</h4>
                                    <?php
                                    if (isset($_REQUEST['msg']) == true)
                                        echo "<div class='alert alert-primary' role='alert'>
						{$_REQUEST['msg']}
						</div>";
                                    ?>

                                    <form class="forms-sample" method="post" action="action/change-password.php" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="txtpassword">Current Password</label>
                                            <input type="passsword" class="form-control" id="txtpassword" name="txtpassword" placeholder="Existing Password">
                                        </div>
                                        <div class="form-group">
                                            <label for="txtnewpassword">New Password</label>
                                            <input type="passsword" class="form-control" id="txtnewpassword" name="txtnewpassword" placeholder="New Password">
                                        </div>
                                        <div class="form-group">
                                            <label for="txtnewpassword2">Confirm New Password</label>
                                            <input type="passsword" class="form-control" id="txtnewpassword2" name="txtnewpassword2" placeholder="Confirm New Password">
                                        </div>
                                        <button type="submit" class="btn btn-gradient-primary mr-2">Save Changes</button>
                                        <button class="btn btn-light">Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div> <!--end of row -->
                    <!--end of row -->
                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <?php require_once("inc/script.php"); ?> 
</body>
</html>