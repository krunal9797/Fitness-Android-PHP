<?php
require_once("inc/verify-login.php");
require_once("../inc/connection.php");
?>
<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php require_once("inc/header-part.php"); ?>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-md-6 stretch-card grid-margin">
                            <div class="card bg-gradient-danger card-img-holder text-white">
                                <div class="card-body">
                                    <h4 class="font-weight-normal mb-3">Diet Plan
                                        <i class="mdi mdi-chart-line mdi-24px float-right"></i>
                                    </h4>
                                    <h2 class="mb-5">
                                        <?php
                                        $sql = "select count(id) 'total' from dietplan";
                                        $result = mysqli_query($link, $sql) or die(mysqli_error($link));
                                        $row = mysqli_fetch_assoc($result);
                                        if ($row['total'] == "")
                                            echo "0";
                                        else
                                            echo $row['total'];
                                        ?>
                                    </h2>
                                    <h6 class="card-text"><a href="dietplan.php" class="card-link text-white">See Detail</a></h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 stretch-card grid-margin">
                            <div class="card bg-gradient-info card-img-holder text-white">
                                <div class="card-body">
                                    <h4 class="font-weight-normal mb-3">Receipe
                                        <i class="mdi mdi-bookmark-outline mdi-24px float-right"></i>
                                    </h4>
                                    <h2 class="mb-5">
                                        <?php
                                        $sql = "select count(id) 'total' from receipe";
                                        $result = mysqli_query($link, $sql) or die(mysqli_error($link));
                                        $row = mysqli_fetch_assoc($result);
                                        if ($row['total'] == "")
                                            echo "0";
                                        else
                                            echo $row['total'];
                                        ?>
                                    </h2>
                                    <h6 class="card-text"><a href="receipe.php" class="card-link text-white">See Detail</a></h6>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 stretch-card grid-margin">
                            <div class="card bg-gradient-warning card-img-holder text-white">
                                <div class="card-body">
                                    <h4 class="font-weight-normal mb-3">Registered Users
                                        <i class="mdi mdi-chart-line mdi-24px float-right"></i>
                                    </h4>
                                    <h2 class="mb-5">
                                        <?php
                                        $sql = "select count(id) 'total' from reg_user";
                                        $result = mysqli_query($link, $sql) or die(mysqli_error($link));
                                        $row = mysqli_fetch_assoc($result);
                                        if ($row['total'] == "")
                                            echo "0";
                                        else
                                            echo $row['total'];
                                        ?>
                                    </h2>
                                    <h6 class="card-text"><a href="reg_user.php" class="card-link text-white">See Detail</a></h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 stretch-card grid-margin">
                            <div class="card bg-gradient-primary card-img-holder text-white">
                                <div class="card-body">
                                    <h4 class="font-weight-normal mb-3">Tips
                                        <i class="mdi mdi-bookmark-outline mdi-24px float-right"></i>
                                    </h4>
                                    <h2 class="mb-5"><h2 class="mb-5">
                                            <?php
                                            $sql = "select count(*) 'total' from tips";
                                            $result = mysqli_query($link, $sql) or die(mysqli_error($link));
                                            $row = mysqli_fetch_assoc($result);
                                            echo $row['total'];
                                            ?> </h2>
                                        <h6 class="card-text"><a href="tips.php" class="card-link text-white">See Detail</a></h6>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <?php require_once("inc/script.php"); ?> 
</body>
</html>