<?php

require_once("../inc/connection.php");
extract($_REQUEST);
$sql = "delete from receipe where id='$id'";
mysqli_query($link, $sql)or die(mysqli_error($link));
$msg = "Deleted successfully";
header("location:receipe.php?msg=$msg");
?>