<?php

require_once("../inc/connection.php");
extract($_REQUEST);
$sql = "delete from tips where id='$id'";
mysqli_query($link, $sql)or die(mysqli_error($link));
$msg = "Deleted successfully";
header("location:tips.php?msg=$msg");
?>