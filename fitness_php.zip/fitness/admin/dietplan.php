<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php
    require_once("inc/header-part.php");
    require_once("../inc/connection.php");
    ?>
    <link href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"  type="text/css" rel="stylesheet" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="card">
                        <div class="card-body">
                            <p class="text-right">
                                <a href="insert-dietplan.php"class="btn btn-primary">Add dietplan</a></p>
                            <h4 class="card-title">Dietplan</h4>
                            <p class="card-description">Existing dietplan</p>
                            <?php
                            if (isset($_REQUEST['msg']) == true)
                                echo "<div class='alert alert-primary' role='alert'>
						{$_REQUEST['msg']}
						</div>";
                            ?>
                            <table id="myTable" class="table table-striped table-bordered table-hover">
                                <thead>
                                <th>Sr no</th>
                                <th>Meal</th>
                                <th>Food</th>
                                <th>Diet Type</th>
                                <th>Operation</th>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "select * from dietplan order by id desc";
                                    $array1 = array("meal", "breakfast", "snack", "lunch", "dinner");
                                    $array2 = array("Standard", "Vegetarian");
                                    $result = mysqli_query($link, $sql) or die(mysqli_error($link));
                                    $count = 1;
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        extract($row);
                                        //var_dump($row);
                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $array1[$meal]; ?></td>
                                            <td><?php echo $food ?></td>
                                            <td><?php echo $array2[$diet_type]; ?></td>
                                            <td><a href="edit-dietplan.php?id=<?php echo $id; ?>"<i class="mdi mdi-border-color"></i></a>&nbsp;<a href="delete-dietplan.php?id=<?php echo $id; ?>"><i class="mdi mdi-delete-forever"></i></a></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>

                        </div>

                    </div>
                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <?php require_once("inc/script.php"); ?> 
    <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#myTable').DataTable();
        });
    </script>
</body>
</html>