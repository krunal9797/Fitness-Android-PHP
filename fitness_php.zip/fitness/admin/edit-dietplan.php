<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php
    require_once("inc/header-part.php");
    require_once("../inc/connection.php");
    extract($_REQUEST);
    $sql = "select * from dietplan where id='$id'";
    $result = mysqli_query($link, $sql) or die(mysqli_error($link));
    $row = mysqli_fetch_assoc($result);
    extract($row);
    $array1 = array("meal", "breakfast", "snack", "lunch", "dinner");
    $array2 = array("Standard", "Vegetarian");
    ?>
</head>
<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="card">
                        <div class="card-body">
                            <?php
                            if (isset($_REQUEST['msg']) == true)
                                echo "<div class='alert alert-primary' role='alert'>
								{$_REQUEST['msg']}
							</div>";
                            ?>
                            <h4 class="card-title">Dietplan</h4><br>
                            <p class="card-description"> <b>Add New Dietplan</b></p>
                            <form class="forms-sample" method="post" action="action/update-dietplan.php">

                                <b>Meal</b><br>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal1" name="rdomeal" class="custom-control-input" value="1" <?php if ($meal == 1) echo "checked"; ?> />
                                    <label class="custom-control-label" for="rdomeal1">Breakfast</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal2" name="rdomeal" class="custom-control-input" value="2" <?php if ($meal == 2) echo "checked"; ?> />
                                    <label class="custom-control-label" for="rdomeal2">Snack</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal3" name="rdomeal" class="custom-control-input" value="3" <?php if ($meal == 3) echo "checked"; ?> />
                                    <label class="custom-control-label" for="rdomeal3">Lunch</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal4" name="rdomeal" class="custom-control-input" value="4" <?php if ($meal == 4) echo "checked"; ?> />
                                    <label class="custom-control-label" for="rdomeal4">Dinner</label>
                                </div>
                                <p></p>
                                <div class="form-group">
                                    <label for="txtfood"><b>Food</label>
                                    <input type="text" class="form-control" id="txtfood" name="txtfood" value="<?php echo $food; ?>" required />
                                </div>

                                <b>Diet type</b><br>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdo1" name="rdo" class="custom-control-input" value="0" <?php if ($diet_type == 0) echo "checked"; ?>>
                                    <label class="custom-control-label" for="rdo1">Standard</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdo2" name="rdo" class="custom-control-input" value="1" <?php if ($diet_type == 1) echo "checked"; ?>>
                                    <label class="custom-control-label" for="rdo2">Vegetarian</label>
                                </div>
                                <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Save Change</button>

                                </div>
                            </form>
                        </div>
                    </div>

                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <?php require_once("inc/script.php"); ?> 
</body>
</html>