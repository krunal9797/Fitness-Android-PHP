<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php
    require_once("inc/header-part.php");
    require_once("../inc/connection.php");
    extract($_REQUEST);
    $sql = "select * from receipe where id='$id'";
    $result = mysqli_query($link, $sql) or die(mysqli_error($link));
    $row = mysqli_fetch_assoc($result);
    extract($row);
    ?>
    <script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="card">
                        <div class="card-body">


                            <h4 class="card-title">Receipt</h4><br>
                            <p class="card-description"> Add New Receipt  </p>
                            <form class="forms-sample" method="post" enctype="multipart/form-data" action="action/update-receipe.php">
                                <div class="form-group">
                                    <label for="txttitle"><b>Title</b></label>
                                    <input type="text" name="txttitle" id="txttitle" class="form-control"  value="<?php echo $title; ?>"required />
                                </div>
                                <div class="form-group">
                                    <label for="txtIngredients"><b>Ingredients</b></label>
                                    <textarea name="txtIngredients" id= "txtIngredients" ><?php echo $Ingredients; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="txthowmake"><b>How to make</b></label>
                                    <textarea name="txthowmake" id="txthowmake"  ><?php echo $howtomake; ?></textarea>
                                </div>
                                <div class="form-group ">
                                    <label for="filphoto"><b>Photo</b></label>
                                    <input type="file" class="form-control" name="filphoto" id="filphoto" accept="image/*" />
                                    <img src="image/receipe/<?php echo $image ?>" class="img-thumbnail"  height="150px" width="150px" />
                                </div>
                                <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
                                <input type="hidden" id="id" name="oldphoto" value="<?php echo $image; ?>">
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Save Change</button>


                            </form>
                        </div>
                    </div>

                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <?php require_once("inc/script.php"); ?> 
    <script>
        CKEDITOR.replace('txtIngredients');
        CKEDITOR.replace('txthowmake');
    </script>
</body>
</html>