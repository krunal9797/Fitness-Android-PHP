<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php
    require_once("inc/header-part.php");
    require_once("../inc/connection.php");
    extract($_REQUEST);
    $sql = "select * from tips where id='$id'";
    $result = mysqli_query($link, $sql) or die(mysqli_error($link));
    $row = mysqli_fetch_assoc($result);
    extract($row);
    ?>
    <script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
<?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
<?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="cart">
                        <div class="cart-body">

                            <h4 class="cart-title">Tips</h4>
                            <p class="cart-description">Add New tips</p>
                            <form class="form-sample" method="post" action="action/update-tips.php">
                                <div class="form-group">
                                    <label for="txttitle"><b>Title</b></label>
                                    <input type="text" class="form-control" id="txttitle" name="txttitle" value="<?php echo $title; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="txtdetail"><b>Detail</b></label>
                                    <textarea name="txtdetail" id="txtdetail"><?php echo $detail; ?></textarea>
                                </div>
                                <input type="hidden" name="id" id="id" value="<?php echo $id; ?>">
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Save Change</button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
<?php require_once("inc/script.php"); ?> 
    <script>
        CKEDITOR.replace('txtdetail');
    </script>
</body>
</html>