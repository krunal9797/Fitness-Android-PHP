-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 12, 2019 at 08:58 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fitness`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'Admin', 'admin@gmail.com', '$2y$12$S6AJM8.MuQY.nJh5CXKdwe6IBxyw.p9e4/sJfvenW6URKpSRZ13ne');

-- --------------------------------------------------------

--
-- Table structure for table `dietplan`
--

DROP TABLE IF EXISTS `dietplan`;
CREATE TABLE IF NOT EXISTS `dietplan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meal` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1-breakfast,2-snack,3-lunch,4-dinner',
  `food` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'food with quantity',
  `diet_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-standard,1-vegetarian',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dietplan`
--

INSERT INTO `dietplan` (`id`, `meal`, `food`, `diet_type`) VALUES
(18, '3', 'vegetables', 0);

-- --------------------------------------------------------

--
-- Table structure for table `receipe`
--

DROP TABLE IF EXISTS `receipe`;
CREATE TABLE IF NOT EXISTS `receipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'receipe title',
  `Ingredients` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'all required things to make this',
  `howtomake` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'cooking instructions',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reg_user`
--

DROP TABLE IF EXISTS `reg_user`;
CREATE TABLE IF NOT EXISTS `reg_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reg_user`
--

INSERT INTO `reg_user` (`id`, `fullname`, `email`, `password`) VALUES
(1, 'mansimehta', 'mansimehta552@gmail.com', '$2y$12$O7LB5uKVr0/QGwNtg9dDi.lofJuYbYtPNZdmMBYr31uHDYZ0h4kfi');

-- --------------------------------------------------------

--
-- Table structure for table `tips`
--

DROP TABLE IF EXISTS `tips`;
CREATE TABLE IF NOT EXISTS `tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'title of healthy tip',
  `detail` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'healthy tip detail',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
