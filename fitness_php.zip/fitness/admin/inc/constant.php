<?php 
	define ('PROJECT_TITLE','Fitness Style');
?>