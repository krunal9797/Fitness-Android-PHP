<?php

function SendMail($receiver, $subject, $content) {
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-type: text/html; charset=iso-8859-1';
    $headers[] = 'To: $receiver';
    $headers[] = 'From: admin@universalnewspapers.com';
    mail($receiver, $subject, $content, implode("\r\n", $headers));
}

function ShowMessage($type) {
    if (isset($_REQUEST['msg']) == true) {
        ?>
        <p></p>
        <div class="alert alert-<?php echo $type; ?> alert-dismissible fade show" role="alert">
            <?php echo $_REQUEST['msg']; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php
    }
}
?>