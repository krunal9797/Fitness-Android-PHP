<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Purple Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="theme/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="theme/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="theme/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="theme/images/favicon.png" />
<!-- end of 1st reusable part -->