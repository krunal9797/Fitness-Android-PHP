<?php

require_once("function.php");
$email = "tnztnz5@gmail.com";
$subject = "password recovery email";
$content = "Hi  <br/> we have just recovered your account. you new password is <b>$newpassword </b> <br/> Thanks you";
SendMail($email, $subject, $content);
