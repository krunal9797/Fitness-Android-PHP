 <!-- start of 4th reusable -->
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="theme/vendors/js/vendor.bundle.base.js"></script>
  <script src="theme/vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="theme/js/off-canvas.js"></script>
  <script src="theme/js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
  <!--end of 4th reusable part -->