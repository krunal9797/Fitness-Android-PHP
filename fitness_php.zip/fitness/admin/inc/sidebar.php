<!-- start of third reusable part -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <a href="#" class="nav-link">
              <div class="nav-profile-image">        
              </div>
              <div class="nav-profile-text d-flex flex-column">
                <span class="font-weight-bold mb-2">Hello Admin</span>
                
              </div>
              <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <span class="menu-title">Dashboard</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
          </li>
		    <li class="nav-item">
            <a class="nav-link" href="dietplan.php">
              <span class="menu-title">Dietplan</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
			  <li class="nav-item">
            <a class="nav-link" href="Receipe.php">
              <span class="menu-title">Receipe</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
		  <li class="nav-item">
            <a class="nav-link" href="reg_user.php">
              <span class="menu-title">Register user</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
          </li>
		    <li class="nav-item">
            <a class="nav-link" href="tips.php">
              <span class="menu-title">Tips</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
        </ul>
      </nav>
      <!--end of 3rd reusable part -->