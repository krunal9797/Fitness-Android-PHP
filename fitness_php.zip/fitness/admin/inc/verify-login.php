<?php

session_start();
if (isset($_SESSION['id']) == false) { //not logged in 
    header("location:index.php?msg=dont be oversmart, login first");
}
?>