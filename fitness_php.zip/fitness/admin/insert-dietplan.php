<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php require_once("inc/header-part.php"); ?>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <?php
                    if (isset($_REQUEST['msg']) == true)
                        echo "<div class='alert alert-primary' role='alert'>
						{$_REQUEST['msg']}
						</div>";
                    ?>
                    <div class="card">
                        <div class="card-body">

                            <h4 class="card-title">Dietplan</h4><br>
                            <p class="card-description"> <b>Add New Dietplan</b></p>
                            <form class="forms-sample" method="post" action="action/insert-dietplan.php">

                                <b>Meal</b><br>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal1" name="rdomeal" class="custom-control-input" value="1">
                                    <label class="custom-control-label" for="rdomeal1">Breakfast</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal2" name="rdomeal" class="custom-control-input" value="2">
                                    <label class="custom-control-label" for="rdomeal2">Snack</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal3" name="rdomeal" class="custom-control-input" value="3">
                                    <label class="custom-control-label" for="rdomeal3">Lunch</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdomeal4" name="rdomeal" class="custom-control-input" value="4">
                                    <label class="custom-control-label" for="rdomeal4">Dinner</label>
                                </div>
                                <p></p>
                                <div class="form-group">
                                    <label for="txtfood"><b>Food</label>
                                    <input type="text" class="form-control" id="txtfood" name="txtfood" required />
                                </div>

                                <b>Diet type</b><br>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdo1" name="rdo" class="custom-control-input" value="0">
                                    <label class="custom-control-label" for="rdo1">Standard</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="rdo2" name="rdo" class="custom-control-input" value="1">
                                    <label class="custom-control-label" for="rdo2">Vegetarian</label>
                                </div>
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Add dietplan</button>
                                    <a href="dietplan.php" class="btn btn-primary">Save and Exit</a>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <?php require_once("inc/script.php"); ?> 
</body>
</html>