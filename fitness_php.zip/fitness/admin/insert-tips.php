<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php require_once("inc/header-part.php"); ?>
    <script src="https://cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="cart">
                        <div class="cart-body">
                            <?php
                            if (isset($_REQUEST['msg']) == true)
                                echo "<div class='alert alert-primary' role='alert'>
								{$_REQUEST['msg']}
							</div>";
                            ?>
                            <p class="text-right"><a href="tips.php" class="btn btn-primary">Back</a></p>
                            <h4 class="cart-title">Tips</h4>
                            <p class="cart-description">Add New tips</p>
                            <form class="form-sample" method="post" action="action/insert-tips.php">
                                <div class="form-group">
                                    <label for="txttitle"><b>Title</b></label>
                                    <input type="text" class="form-control" id="txttitle" name="txttitle">
                                </div>
                                <div class="form-group">
                                    <label for="txtdetail"><b>Detail</b></label>
                                    <textarea name="txtdetail" id="txtdetail"  ></textarea>
                                </div>
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Add Tips</button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>

            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <?php require_once("inc/script.php"); ?> 
    <script>
        CKEDITOR.replace('txtdetail');
    </script>
</body>
</html>