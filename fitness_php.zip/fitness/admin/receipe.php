<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php
    require_once("inc/header-part.php");
    require_once("../inc/connection.php");
    ?>
    <link href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"  type="text/css" rel="stylesheet" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="card">
                        <div class="card-body">
                            <?php
                            if (isset($_REQUEST['msg']) == true)
                                echo "<div class='alert alert-primary' role='alert'>
								{$_REQUEST['msg']}
							</div>";
                            ?>
                            <p class="text-right"><a href="insert-receipe.php" class="btn btn-primary">Add Receipe</a></p>
                            <h4 class="card-title">Receipe</h4>
                            <p class="card-description">Existing Receipe</p>
                            <table id="myTable" class="table table-striped table-bordered table-hover">
                                <thead>
                                <th>Sr no</th>
                                <th>Title</th>
                                <th>Ingredients</th>
                                <th>How to make</th>
                                <th>Photo</th>
                                <th>Operation</th>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "select * from receipe order by id desc";
                                    $result = mysqli_query($link, $sql) or die(mysqli_error($link));
                                    $count = 1;
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        extract($row);
                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $title; ?></td>
                                            <td><?php echo $Ingredients ?></td>
                                            <td><?php echo $howtomake; ?></td>
                                            <td><img src="image/receipe/<?php echo $image; ?>"style="height:100px !important;width: 100px!important" required /></td>
                                            <td><a href="edit-receipe.php?id=<?php echo $id; ?>"<i class="mdi mdi-border-color"></i></a>&nbsp;<a href="delete-receipe.php?id=<?php echo $id; ?>"><i class="mdi mdi-delete-forever"></i></a></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
        </div>
        <?php require_once("inc/script.php"); ?> 
        <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script>
            $(document).ready(function () {
                $('#myTable').DataTable();
            });
        </script>
</body>
</html>