<!-- start of 1st reusable part -->
<!DOCTYPE html>
<html lang="en">

    <?php
    require_once("inc/header-part.php");
    require_once("../inc/connection.php");
    ?>
    <link href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"  type="text/css" rel="stylesheet" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php require_once("inc/top-navigation.php"); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php require_once("inc/sidebar.php"); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="card">
                        <div class="card-body">
                            <?php
                            if (isset($_REQUEST['msg']) == true)
                                echo "<div class='alert alert-primary' role='alert'>
								{$_REQUEST['msg']}
							</div>";
                            ?>
                            <p class="text-right"><a href="insert-tips.php" class="btn btn-primary">Add Tips</a></p>
                            <h4 class="card-title">Tips</h4>
                            <p class="card-description">Existing Tips</p>
                            <table id="myTable" class="table table-striped table-bordered table-hover">
                                <thead>
                                <th>Sr no</th>
                                <th>Title</th>
                                <th>Detail</th>
                                <th>Operation</th>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "select * from tips order by id desc";
                                    $result = mysqli_query($link, $sql)or die(mysqli_error($link));
                                    $count = 1;
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        extract($row);
                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $title; ?></td>
                                            <td><?php echo $detail; ?></td>
                                            <td><a href="edit-tips.php?id=<?php echo $id; ?>"><i class="mdi mdi-border-color"></i></a>&nbsp;<a href="delete-tips.php?id=<?php echo $id; ?>"><i class="mdi mdi-delete-forever"></i></a></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>	
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
        </div>
        <?php require_once("inc/script.php"); ?> 
        <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script>
            $(document).ready(function () {
                $('#myTable').DataTable();
            });
        </script>
</body>
</html>