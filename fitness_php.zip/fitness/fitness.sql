-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 10, 2019 at 10:27 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fitness`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'Admin', 'admin@gmail.com', '$2y$10$.Lc/MEz5lxo9Ruf7yDVvxuLNkLeeSkz3Rqv9m3SihEUpgv.3CZnQO');

-- --------------------------------------------------------

--
-- Table structure for table `dietplan`
--

DROP TABLE IF EXISTS `dietplan`;
CREATE TABLE IF NOT EXISTS `dietplan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meal` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1-breakfast,2-snack,3-lunch,4-dinner',
  `food` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'food with quantity',
  `diet_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-standard,1-vegetarian',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dietplan`
--

INSERT INTO `dietplan` (`id`, `meal`, `food`, `diet_type`) VALUES
(1, '1', 'idli-1,dosa-1,sandwich-1\r\n\r\n', 0),
(2, '1', 'poha-1,upma-1\r\n', 0);

-- --------------------------------------------------------

--
-- Table structure for table `receipe`
--

DROP TABLE IF EXISTS `receipe`;
CREATE TABLE IF NOT EXISTS `receipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'receipe title',
  `Ingredients` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'all required things to make this',
  `howtomake` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'cooking instructions',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `receipe`
--

INSERT INTO `receipe` (`id`, `title`, `Ingredients`, `howtomake`, `image`) VALUES
(1, 'pav-bhaji', 'vegetables,pav,bhajiMasala,butter', 'Boil the veggies first and keep them ready. ...\r\nHeat 1 tablespoon of butter and 1 tablespoon of oil in a large pot on medium heat. ...\r\nAdd the chopped onions and mix. ...\r\nCook the onions for around 4 minutes until golden brown in color.\r\nAdd the finely chopped ginger, garlic and green chili.', 'img1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reg_user`
--

DROP TABLE IF EXISTS `reg_user`;
CREATE TABLE IF NOT EXISTS `reg_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reg_user`
--

INSERT INTO `reg_user` (`id`, `fullname`, `email`, `password`) VALUES
(1, 'mansimehta', 'mansimehta@552gmail.com', '$2y$12$r8eQfqt6xANynJH6RiKXUuLhwhjLZlAYYeQssexlddboAQJSLwU9a');

-- --------------------------------------------------------

--
-- Table structure for table `tips`
--

DROP TABLE IF EXISTS `tips`;
CREATE TABLE IF NOT EXISTS `tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'title of healthy tip',
  `detail` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'healthy tip detail',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tips`
--

INSERT INTO `tips` (`id`, `title`, `detail`) VALUES
(1, ' Health and Nutrition Tips', 'Don\'t Drink Sugar Calories. Sugary drinks are the most fattening things you can put into your body. ...\r\nEat Nuts. ...\r\nAvoid Processed Junk Food (Eat Real Food Instead) ...\r\nDon\'t Fear Coffee. ...\r\nEat Fatty Fish. ...\r\nGet Enough Sleep. ...\r\nTake Care of Your Gut Health With Probiotics and Fiber. ...\r\nDrink Some Water, Especially Before Meals.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
