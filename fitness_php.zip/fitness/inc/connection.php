<?php 
	date_default_timezone_set("asia/kolkata");
	define("PRINT_ERROR",true);
	//error_reporting(0);
	$response = array();
	define("SERVER","localhost");
	define("USERNAME","root");
	define("PASSWORD","root");
	$link = mysqli_connect(SERVER,USERNAME,PASSWORD) or (ReturnError("invalid username/password/servername"));
	define("DATABASE","fitness");
	mysqli_select_db($link,DATABASE) or (ReturnError());
	function ReturnError($msg=null,$line="") //default argument
	{
		$CurrentDateTime = date("D d-m-Y h:i:s A");
		if(!PRINT_ERROR)
			echo json_encode(array(array("error"=>"oops something went wrong")));
		else 
		{
			if($msg==null)
				array_push($GLOBALS['response'],array("error"=>mysqli_error($GLOBALS['link']) . " in " . $GLOBALS['sql'] . " at line no " .  $line));
			else 
				array_push($GLOBALS['response'],array("error"=>$msg));
			echo json_encode($GLOBALS['response']);
		} 
		
		//$sql2 = "insert into error (filename,error,query,datetime,line) values ('{$GLOBALS['FileName']}','" . mysqli_real_escape_string($GLOBALS['link'],mysqli_error($GLOBALS['link'])) . "','" . mysqli_real_escape_string($GLOBALS['link'],$GLOBALS['sql']) ."','$CurrentDateTime',$line)";
		//mysqli_query($GLOBALS['link'],$sql2);	
		exit;
	}
	function EncryptPassword($OriginalPassword)
	{
		$options = ['cost' => 12];
		return password_hash($OriginalPassword, PASSWORD_BCRYPT, $options);
	}
	function MatchPassword($ExistingPassword /* already encrypted password */,$OriginalPassword)
	{
		 return password_verify ($OriginalPassword,$ExistingPassword);
	}
	function dmy($date,$short=false)
	{
		if($short==false)
			return date("d-m-Y ",strtotime($date));
		else 
			return date("d-m-Y h:i:s A",strtotime($date));
	}
?>