<?php

function SendMail($receiver, $subject, $content) {
    if ($_SERVER['SERVER_NAME'] == "localhost") {
        /* please read below instruction to send email 
          this code is working perfectly and we just need to do following  things

          open php.ini file and uncomment following line in file
          ;php_openssl.dll
          remove ;(semicolon) from begging and then it will look like following
          php_openssl.dll
          and then restart wamp server.

          then login into your gmail account & in same browser copy paste below url
          https://www.google.com/settings/security/lesssecureapps
          into address bar
          and then enable less secure mail option (turn on)
         */
        require_once('../lib/class.phpmailer.php');
        $UserName = "demo@gmail.com"; // replace with your own gmail email address
        $Password = "demo"; // replace with your own gmail email password
        $SenderEmailAddress = "demo@gmail.com"; // replace with your own gmail email address
        $ContactName = "Name"; // replace with your own name
        $ReceiverName = $receiver; // replace with your receiver email address, passed as an argument in function 
        $mail = new PHPMailer(true);
        $mail->IsSMTP();
        try {
            $mail->Host = "mail.gmail.com";  // SMTP server
            $mail->SMTPDebug = 0;                     // enables SMTP debug information (for testing)
            $mail->SMTPAuth = true;                  // enable SMTP authentication
            $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
            $mail->Host = "smtp.gmail.com";      // sets GMAIL as the SMTP server
            $mail->Port = 465;                   // set the SMTP port for the GMAIL server
            $mail->Username = $UserName;  // GMAIL username
            $mail->Password = $Password;            // GMAIL password
            $mail->AddReplyTo($SenderEmailAddress, $SenderEmailAddress);
            $mail->AddAddress($receiver, $receiver);
            $mail->SetFrom($SenderEmailAddress, $SenderEmailAddress);

            //$mail->AddReplyTo($SenderEmailAddress,$ContactName);
            $mail->Subject = $subject;
            // replace with your subject, passed as an argument in function 
            $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!';
            $mail->Body = $content; // replace with your mail content, passed as an argument in function 
            $mail->Send();
            //echo "Message Sent OK<p></p>\n";
        } catch (phpmailerException $e) {
            echo $e->errorMessage();
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}
?>