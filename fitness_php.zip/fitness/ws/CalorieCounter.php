<?php

//http://localhost/project1/ws/CalorieCounter.php
require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);
$sql = "select * from CalorieCounter order by title";
$result = mysqli_query($link, $sql) or die(ReturnError(null, __LINE__));
$count = mysqli_num_rows($result);
if ($count == 0) {
    array_push($response, array("error" => "no error"));
    array_push($response, array("total" => $count));
    array_push($response, array("message" => "Nothing found"));
} else {
    array_push($response, array("error" => "no error"));
    array_push($response, array("total" => $count));
    while ($row = mysqli_fetch_assoc($result)) {
        extract($row);
        array_push($response, array("id" => $id, "title" => $title, "calorie" => $calorie, "weight" => $weight));
    }
}
echo json_encode($response);
?>