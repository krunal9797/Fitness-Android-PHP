<?php 
	//http://localhost:8888/project1/ws/addtofood.php?reg_userid=1&caloriecounterid=1
	require_once("../connection.php");
	$FileName = basename($_SERVER['SCRIPT_NAME']);
	if (isset($_REQUEST['reg_userid']) == false || isset($_REQUEST['caloriecounterid']) == false) 
	{
    	ReturnError("input(s) missing");
	} 
	else 
	{
    	extract($_REQUEST);
    	$sql = "INSERT INTO `mycalorie` (`id`, `reg_userid`, `caloriecouterid`) VALUES (null,'$reg_userid','$caloriecounterid')";
    	mysqli_query($link,$sql) or die(ReturnError(null,__LINE__));
    	array_push($response, array("error" => "no error"));
    	array_push($response, array("message" => "Item added into food"));
   }
   echo json_encode($response);
?>