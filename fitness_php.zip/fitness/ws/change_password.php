<?php
//http://localhost/project1/ws/change_password.php?oldpwd=1516095&newpwd=957474&id=1
require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);

if (isset($_REQUEST['oldpwd']) == false || isset($_REQUEST['newpwd']) == false || isset($_REQUEST['id']) == false)
{
	  ReturnError("input(s) missing");
}
else
{
	extract($_REQUEST);
	$sql="select id,password from reg_user where id='$id'";
	$result=mysqli_query($link,$sql) or die(ReturnError(null, __LINE__));
	$count=mysqli_num_rows($result);
	if($count==0)
	{
	   array_push($response, array("error" => "no error"));
	   array_push($resonse, array("success"=>"not"));
	   array_push($response, array("message" => "user not found"));
	}
	else
	{
		$row = mysqli_fetch_assoc($result);
		$ExistingPassword=$row['password'];
		if(MatchPassword($ExistingPassword,$oldpwd)==false)
		{
			array_push($response, array("error" => "no error"));
            array_push($response, array("success" => "no"));
            array_push($response, array("message" => "invalid password"));
		}
		else
		{
			 $newpwd = EncryptPassword($newpwd);
			 $sql="update reg_user set password='$newpwd'where id='$id'";
			 mysqli_query($link,$sql) or die(ReturnError(null, __LINE__));
			 array_push($response, array("error" => "no error"));
             array_push($response, array("success" => "yes"));
             array_push($response, array("message" => "Password  have been changed"));
		}
	}
}

echo json_encode($response);


?>