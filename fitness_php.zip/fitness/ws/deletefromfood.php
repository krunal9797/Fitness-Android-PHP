<?php 
	//http://localhost:8888/project1/ws/deletefromfood.php?id=2
	require_once("../connection.php");
	$FileName = basename($_SERVER['SCRIPT_NAME']);
	if (isset($_REQUEST['id']) == false) 
	{
    	ReturnError("input(s) missing");
	} 
	else 
	{
    	extract($_REQUEST);
    	$sql = "delete from `mycalorie` where id=$id";
    	mysqli_query($link,$sql) or die(ReturnError(null,__LINE__));
    	array_push($response, array("error" => "no error"));
    	array_push($response, array("message" => "Item deleted from food"));
   }
   echo json_encode($response);
?>