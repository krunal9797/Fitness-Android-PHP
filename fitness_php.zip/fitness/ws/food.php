<?php 
	//http://localhost:8888/project1/ws/reg_userid.php?reg_userid=1
	require_once("../connection.php");
	$FileName = basename($_SERVER['SCRIPT_NAME']);
	if (isset($_REQUEST['reg_userid']) == false) 
	{
    	ReturnError("input(s) missing");
	} 
	else 
	{
    	extract($_REQUEST);
    	$sql = "select m.id,title,weight,calorie from `mycalorie` m ,caloriecounter c where reg_userid=$reg_userid and m.caloriecouterid=c.id";
    	$result = mysqli_query($link,$sql) or die(ReturnError(null,__LINE__));
    	
    	$calorietotal=0;
    	while($row = mysqli_fetch_assoc($result))
    	{
    		array_push($response,$row);
    		$calorietotal+= $row['calorie'];
    	}
    	array_unshift($response, array("calorietotal" => $calorietotal));
    	array_unshift($response, array("total" => mysqli_num_rows($result)));
    	array_unshift($response, array("error" => "no error"));

   }
   echo json_encode($response);
?>