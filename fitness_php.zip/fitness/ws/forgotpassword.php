<?php

//http://localhost:8888/project1/ws/forgotpassword.php?email=mansimehta@552gmail.com

require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);
extract($_REQUEST);
if (isset($_REQUEST['email']) == false) {
    ReturnError("input(s) missing");
} else {
    extract($_REQUEST);
    $sql = "select count(*) 'total' from reg_user where email='$email'";
    $result = mysqli_query($link, $sql) or die(ReturnError(null, __LINE__));
    $row = mysqli_fetch_assoc($result);
    if ($row['total'] == 0) {
        array_push($response, array("error" => "no"));
        array_push($response, array("success" => "no"));
        array_push($response, array("message" => "invalid email address"));
    } else {
        $newpassword = mt_rand(10, 99) . mt_rand(10, 99) . mt_rand(10, 99) . mt_rand(10, 99);
        $EncryptedPassword = EncryptPassword($newpassword);
        $sql = "update reg_user set password='$EncryptedPassword' where email='$email'";
        mysqli_query($link, $sql) or die(ReturnError(null, __LINE__));
        array_push($response, array("success" => "yes"));
        array_push($response, array("message" => "Password send to you"));
        require_once("../function.php");
        $subject = "password recovery email";
        $content = "Hi  <br/> we have just recovered your account. you new password is <b>$newpassword </b> <br/> Thanks you";
        SendMail($email, $subject, $content);
    }
}
array_unshift($response, array("error" => "no error"));
echo json_encode($response);
?>