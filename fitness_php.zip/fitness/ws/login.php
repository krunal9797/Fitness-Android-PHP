<?php

//http://localhost/project1/ws/login.php?email=admin@gmail.com&password=123123
require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);
if (isset($_REQUEST['email']) == false || isset($_REQUEST['password']) == false) {
    ReturnError("input(s) missing");
} else {
    extract($_REQUEST);
    $sql = "select id,password from reg_user where email='$email'";
    $result = mysqli_query($link, $sql) or die(ReturnError(null, __LINE__));
    $row = mysqli_fetch_assoc($result);
    $total = mysqli_num_rows($result);
    if ($total == 0) {
        array_push($response, array("error" => "no error"));
        array_push($response, array("success" => "no"));
        array_push($response, array("message" => "invalid email address"));
    } else {
        $ExistingPassword = $row['password'];
        if (MatchPassword($ExistingPassword, $password) == false) {
            array_push($response, array("error" => "no error"));
            array_push($response, array("success" => "no"));
            array_push($response, array("message" => "invalid password"));
        } else {
            array_push($response, array("error" => "no error"));
            array_push($response, array("success" => "yes"));
            array_push($response, array("message" => "Fitness Style welcomes you"));
            array_push($response, array("id" => $row['id']));
        }
    }
}
echo json_encode($response);
?>