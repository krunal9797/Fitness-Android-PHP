<?php 
	$password = "123123";
	echo password_hash($password,PASSWORD_DEFAULT);
?>