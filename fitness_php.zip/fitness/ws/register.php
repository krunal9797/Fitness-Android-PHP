<?php

//http://localhost/project1/ws/register.php?fullname=mansimehta&email=mansimehta@552gmail.com&password=1516095
require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);
if (isset($_REQUEST['fullname']) == false || isset($_REQUEST['email']) == false || isset($_REQUEST['password']) == false) {
    ReturnError("input(s) missing");
} else {
    extract($_REQUEST);
    $sql = "select count(*) 'total' from reg_user where email='$email'";
    $result = mysqli_query($link, $sql) or die(ReturnError(null, __LINE__));
    $row = mysqli_fetch_assoc($result);
    extract($row);
    if ($total >= 1) {
        array_push($response, array("error" => "no error"));
        array_push($response, array("success" => "no"));
        array_push($response, array("message" => "email is already in use, please give unique email/mobile"));
    } else {
        $password = EncryptPassword($password);
        $sql = "insert into reg_user(fullname,email,password)values('$fullname','$email','$password')";
        mysqli_query($link, $sql) or die(ReturnError(null, __LINE__));
        array_push($response, array("error" => "no error"));
        array_push($response, array("success" => "yes"));
        array_push($response, array("message" => " register successfully"));
    }
}
echo json_encode($response);
?>