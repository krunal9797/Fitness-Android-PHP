<?php
//http://localhost/project1/ws/view-dietplan.php
require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);
$sql="select * from dietplan";
$result=mysqli_query($link,$sql) or die ( ReturnError(null, __LINE__));
$count=mysqli_num_rows($result);
if($count==0)
{
	
	array_push($response,array("error"=>"no"));
	array_push($response,array("message"=>"dietplan not found"));
	
}
else
{
	array_push($response,array("error"=>"no"));
	array_push($response,array("total"=>$count));
while($row=mysqli_fetch_assoc($result))
{
	extract($row);
	array_push($response,array("meal"=>$meal,"food"=>$food,"diet_type"=>$diet_type));
}
}
echo json_encode($response);	

?>