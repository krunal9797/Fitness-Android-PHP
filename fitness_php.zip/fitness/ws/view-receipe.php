<?php
//http://localhost/project1/ws/view-receipe.php
require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);
$sql="select * from receipe";
$result=mysqli_query($link,$sql) or die ( ReturnError(null, __LINE__));
$count=mysqli_num_rows($result);
if($count==0)
{
	
	array_push($response,array("error"=>"no"));
	array_push($response,array("message"=>" Recepie not found"));
	
}
else
{
	array_push($response,array("error"=>"no"));
	array_push($response,array("total"=>$count));
while($row=mysqli_fetch_assoc($result))
{
	extract($row);
	array_push($response,array("title"=>$title,"ingredients"=>$Ingredients,"howtomake"=>$howtomake,"image"=>$image));
}
}
echo json_encode($response);	

?>