<?php
//http://localhost/project1/ws/view-tips.php
require_once("../connection.php");
$FileName = basename($_SERVER['SCRIPT_NAME']);
$sql="select * from tips";
$result=mysqli_query($link,$sql) or die ( ReturnError(null, __LINE__));
$count=mysqli_num_rows($result);
if($count==0)
{
	array_push($response,array("error"=>"no"));
	array_push($response,array("total"=>$count));
	array_push($response,array("message"=>"Tips not found"));
}
else
{
	array_push($response,array("error"=>"no"));
	array_push($response,array("total"=>$count));
	while($row=mysqli_fetch_assoc($result))
	{
		extract($row);
		array_push($response,array("title"=>$title,"detail"=>$detail));
	}
}
echo json_encode($response);	

?>